# modified by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from urllib.parse import quote_plus, unquote_plus
from cocoscrapers.modules import coco_client as client, coco_compat as source_utils


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	headers = {'User-Agent': client.randomagent()}
	def __init__(self):
		self.language = ['en']
#		self.domains = [
#			'kick4ss.com', 'thekat.info', 'kickasst.net', 'kickasshydra.dev', 'kickasshydra.net',
#			'kathydra.com', 'kickasstorrents.id', 'thekat.cc', 'kkat.net', 'kickasstorrents.bz',
#			'kickass.ws', 'kickass.cm', 'kickass.onl'
#		]
		self.base_link = "https://kick4ss.com"
		self.search_link = '/usearch/{}%20category:{}'
		self.min_seeders = 0

	def get_sources(self, url, collector):
		try:
			results = client.session.request('get', url, headers=self.headers, timeout=7).text
			if not results: return
			rows = client.parseDOM(results, 'tr', attrs={'id': 'torrent_latest_torrents'})
			files = []
			for row in rows:
				try:
					columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)
					url = unquote_plus(columns[0]).replace('&amp;', '&')
					url = re.search(r'(magnet:.+?)&tr=', url, re.I).group(1).replace(' ', '.')
					hash = re.search(r'btih:(.*?)&', url, re.I).group(1)
					parsed_title = unquote_plus(url.split('&dn=')[1]) # some links on kickass dbl encoded
					try: seeders = columns[3].replace(',', '')
					except: seeders = 0
					size = columns[1].split('<')[0]
					files.append({'hash': hash, 'title': parsed_title, 'seeders': seeders, 'size': size})
				except: pass
			collector.extend(files)
		except:
			source_utils.scraper_error('KICKASS2')

	@source_utils.airdate_sources
	def sources(self, data, hostDict):
		airdate = source_utils.episode_airdate(data) if data and 'tvshowtitle' in data else None
		if not data: return []
		files = []
		sources = []
		sources_append = sources.append
		try:
			aliases = source_utils.aliases_to_array(data['aliases'])
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			hdlr = source_utils.episode_identifier(data, 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else year)
			category = 'tv' if 'tvshowtitle' in data else 'movies'

			query = '%s %s' % (title, hdlr)
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', query)
			url = self.search_link.format(quote_plus(query), category)
			urls = ['%s%s' % (self.base_link, url), '%s%s%s' % (self.base_link, url, '/?p=2')]
			# log_utils.log('urls = %s' % urls)
			thread = source_utils.Thread(self.get_sources, urls[0], files)
			thread.start()
			self.get_sources(urls[1], files)
			thread.join()
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('KICKASS2')
			return sources

		for file in files:
			try:
				hash = file['hash']
				name = file['title']

				name = source_utils.clean_name(name)

				if not source_utils.check_title(title, aliases, name, hdlr, year, airdate=airdate): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title, airdate=airdate)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				if not episode_title: #filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(file['seeders'])
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = file['size']
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				sources_append({
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'kickass2', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				})
			except:
				source_utils.scraper_error('KICKASS2')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		if not data: return []
		files = []
		sources = []
		sources_append = sources.append
		try:
			aliases = source_utils.aliases_to_array(data['aliases'])
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			imdb = data['imdb']
			year = data['year']
			season_x = data['season']
			season_xx = season_x.zfill(2)
			category = 'tv'

			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', title)
			if search_series: urls = [
				self.base_link + self.search_link.format(quote_plus(query + ' Season'), category),
				self.base_link + self.search_link.format(quote_plus(query + ' Complete'), category)]
			else: urls = [
				self.base_link + self.search_link.format(quote_plus(query + ' S%s' % season_xx), category),
				self.base_link + self.search_link.format(quote_plus(query + ' Season %s' % season_x), category)]
			thread = source_utils.Thread(self.get_sources, urls[0], files)
			thread.start()
			self.get_sources(urls[1], files)
			thread.join()
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('KICKASS2')
			return sources

		for file in files:
			try:
				hash = file['hash']
				name = file['title']

				name = source_utils.clean_name(name)

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season_x, name)
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season_x, name, total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				name_info = source_utils.info_from_name(name, title, year, season=season_x, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(file['seeders'])
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = file['size']
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'kickass2', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('KICKASS2')
		return sources

