# Nimbus Skin for Kodi Omega

 https://rb.gy/l9zpkl

## INFO

Kodi File Manager Source: [https://ivarbrandt.github.io/repository.ivarbrandt/](https://ivarbrandt.github.io/repository.ivarbrandt/)
